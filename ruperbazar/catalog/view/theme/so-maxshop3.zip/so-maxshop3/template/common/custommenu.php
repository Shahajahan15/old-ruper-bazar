<li class="dropdown sub">
	<a> Featured </a>
	<div class="dropdown-menu featured" style="width: 850px;">
		<div class="column col-lg-3 col-md-4 col-sm-6">
			<a>Layouts</a>
			<div>
				<ul class="row-list"> 
					<li><a href="http://dev.ytcvn.com/ytc_templates/opencart/so_market/index.php?layoutbox=full">Home I - Shop 1 - Full Width</a></li>
					<li><a href="http://dev.ytcvn.com/ytc_templates/opencart/so_market/index.php?layoutbox=boxed&amp;pattern=12">Home I - Shop 1 - Layout Box</a></li>
					<li><a href="http://dev.ytcvn.com/ytc_templates/opencart/so_market/layout2/index.php?layoutbox=full">Home II - Shop 2 - Right Sidebar</a></li>
					<li><a href="http://dev.ytcvn.com/ytc_templates/opencart/so_market/layout3/index.php?layoutbox=full">Home III - Shop 3 - Left Sidebar</a></li>
					<li><a href="http://dev.ytcvn.com/ytc_templates/opencart/so_market/layout4/index.php?layoutbox=full">Home IV - Shop 4 - Full Width</a></li>
				
				</ul>

			</div>
		
		</div>
		<div class="column col-lg-3 col-md-4 col-sm-6">
			<a>Theme Colors</a>
			<div>
				<ul class="row-list"> 
					<li class="color orange"><a href="index.php?scheme=default">Orange Color</a></li>
					<li class="color green"><a href="index.php?scheme=green">Green Color</a></li>
					<li class="color cyan"><a href="index.php?scheme=cyan">Cyan Color</a></li>
					<li class="color boocdo"><a href="index.php?scheme=boocdo">Boocdo Color</a></li>
					<li class="color blue"><a href="index.php?scheme=blue">Blue Color</a></li> 
				
				</ul>
			</div>
				
			
		</div>
		
		<div class="column col-lg-3 col-md-4 col-sm-6">
			<a>Listing</a>
			<div>
				<ul class="row-list"> 
					<li><a href="#">With Left Column</a></li>
					<li><a href="#">No Left Column</a></li>
					<li><a href="#">Only Categories</a></li> 
				</ul>
			</div>
			
		</div>
		
		<div class="column col-lg-3 col-md-4 col-sm-6">
			
			<a>Detail</a>
			<div>
				<ul class="row-list"> 
					<li><a href="#">With Right Column</a></li> 
					<li><a href="#">No Right Column</a></li> 
					<li><a href="#">Thumbnails bottom</a></li>
					<li><a href="#">Thumbnails Left</a></li>
					<li><a href="#">Tab Bottom vertical</a></li>
					<li><a href="#">Tab Bottom horizontal</a></li> 
					<li><a href="#">Tab Collapsed in product description</a></li> 
				</ul>
			</div>
			
		</div>
		
	</div>
</li>





